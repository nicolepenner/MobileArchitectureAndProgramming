package com.example.project3nicolepenner;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.Button;
import android.text.Editable;
import android.widget.EditText;
import android.text.TextWatcher;
import android.widget.Toast;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NavUtils;

public class editInventoryItems extends AppCompatActivity {

    public static final String EXTRA_ITEM = "com.example.project3nicolepenner.item";

    // Inventory databaseHelper created
    com.example.project3nicolepenner.databaseHelper databaseHelper;
    EditText inventory;
    EditText quantity;
    Button saveButton;
    Button deleteButton;

    // Edit the current item selected
    private inventoryClass currentItem;

    @Override
    // Single item databaseHelper edit
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        setContentView(R.layout.edit_item);

        databaseHelper = databaseHelper.getInstance(this);
        inventory = findViewById(R.id.editItemName);
        quantity = findViewById(R.id.editInventoryQuantity);
        saveButton = findViewById(R.id.save);

        // Hide delete button when not in use
        deleteButton = findViewById(R.id.deleteButton);

        //remove delete button
        deleteButton.setVisibility(View.GONE);

        // Save button does not show up automatically
        saveButton.setEnabled(false);

        //Quantity will be 0 at start
        int initialQuantity = 0;

        // Gets item edit view
        inventoryClass item = (inventoryClass) getIntent().getSerializableExtra(EXTRA_ITEM);
        if (item != null) {
            currentItem = item;
            inventory.setText(item.getName());
            initialQuantity = item.getQuantity();
            deleteButton.setVisibility(View.VISIBLE);
        }

        // Initali quantity grabbed
        quantity.setText(String.valueOf(initialQuantity));

        // Make changes to the item
        inventory.addTextChangedListener(textWatcher);  // Save any name changes
        quantity.addTextChangedListener(textWatcher);   // Save any quantity changes
    }

    // Text watcher method to apply changes
    private final TextWatcher textWatcher = new TextWatcher() {
        @Override
        // Notify of changes beginning at start are about to be replaced
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        // Notify that changes within ->s<- have been replaced with new text with length
        public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
            saveButton.setEnabled(!getInventory().isEmpty());
        }

        @Override
        // Called to notify you that text has changed
        public void afterTextChanged(Editable s) {
        }
    };

    // Save new items or edited items to the databaseHelper
    public void handleSaveItem(View view) {
        boolean saved;

        // If currentItem is not null, update new name and quantity
        if (currentItem != null) {
            currentItem.setName(getInventory());
            currentItem.setQuantity(getItemQuantity());
            saved = databaseHelper.itemUpdate(currentItem);
        } else {
            // If currentItem is null, save name and quantity to databaseHelper
            saved = databaseHelper.itemAdd(getInventory(), getItemQuantity());
        }

        // Upon save, revert back to inventory list screen otherwise throw an error message
        if (saved) {
            NavUtils.navigateUpFromSameTask(this);
        } else {
            Toast.makeText(editInventoryItems.this, R.string.save_error, Toast.LENGTH_SHORT).show();
        }
    }

    // Delete an item
    public void handleDeleteItem(View view) {
        new AlertDialog.Builder(this).setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle(R.string.delete_confirmation_title).setMessage(R.string.delete_confirmation)
                .setPositiveButton("Yes", (dialog, which) -> {
                    // Delete item
                    boolean deleted = databaseHelper.itemDelete(currentItem);
                    finish();

                    // Delete else throw error
                    if (deleted) {
                        NavUtils.navigateUpFromSameTask(editInventoryItems.this);
                    } else {
                        Toast.makeText(editInventoryItems.this, R.string.delete_error, Toast.LENGTH_SHORT).show();
                    }
                }).setNegativeButton("No", null).show();
    }

    //    Increase by 1
    public void quantityIncrement(View view) {
        quantity.setText(String.valueOf(getItemQuantity() + 1));
    }

    //    Decrease by 1
    public void quantityDecrement(View view) {
        quantity.setText(String.valueOf(Math.max(0, getItemQuantity() - 1)));
    }

    //  Get item name
    private String getInventory() {
        Editable name = inventory.getText();
        return name != null ? name.toString().trim() : "";
    }


    //    Get item quantity
    private int getItemQuantity() {
        String rawValue = quantity.getText().toString().replaceAll("[^\\d.]", "").trim();
        int quantity = rawValue.isEmpty() ? 0 : Integer.parseInt(rawValue);

        // Quantity cannot be less than 0
        return Math.max(quantity, 0);
    }
}

