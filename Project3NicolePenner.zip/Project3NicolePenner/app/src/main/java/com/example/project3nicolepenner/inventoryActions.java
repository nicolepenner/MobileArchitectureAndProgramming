package com.example.project3nicolepenner;

import static com.example.project3nicolepenner.R.*;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class inventoryActions extends RecyclerView.Adapter<inventoryActions.ItemHolder> {
    private static final String TAG = "ItemAdapter";
    private final List<inventoryClass> classInventory;
    private final Context contextItem;

    com.example.project3nicolepenner.databaseHelper databaseHelper;

    public inventoryActions(List<inventoryClass> items, Context context, com.example.project3nicolepenner.databaseHelper inventoryDatabaseHelper) {
        classInventory = items;
        contextItem = context;
        databaseHelper = inventoryDatabaseHelper;
    }

    @NonNull
    @Override
    public ItemHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        final View view = LayoutInflater.from(parent.getContext()).inflate(layout.new_inventory_item, parent, false);
        return new ItemHolder(view, databaseHelper);
    }

    @SuppressLint({"NonConstantResourceId", "NotifyDataSetChanged"})
    @Override
    public void onBindViewHolder(ItemHolder holder, @SuppressLint("RecyclerView") int position) {
        inventoryClass item = classInventory.get(position);
        holder.bindItem(item);

        holder.actionsButtons.setOnClickListener(v -> {
            PopupMenu popup = new PopupMenu(contextItem, holder.actionsButtons);
            popup.inflate(menu.menu_button_options);
            popup.setOnMenuItemClickListener(menuItem -> {
                switch (menuItem.getItemId()) {
                    case id.menu_edit:
                        Log.i(TAG, "edit item at position " + position);

                        Intent intent = new Intent(contextItem, editInventoryItems.class);
                        intent.putExtra(editInventoryItems.EXTRA_ITEM, item);
                        contextItem.startActivity(intent);

                        return true;
                    case id.menu_remove:
                        Log.i(TAG, "remove item at position " + position);

                        new AlertDialog.Builder(contextItem).setIcon(android.R.drawable.ic_dialog_alert)
                                .setTitle(string.delete_confirmation_title).setMessage(string.delete_confirmation)
                                .setPositiveButton("Yes", (dialog, which) -> {
                                    boolean deleted = databaseHelper.itemDelete(item);
                                    if (deleted) {
                                        classInventory.remove(position);
                                        notifyItemRemoved(position);
                                        notifyDataSetChanged();
                                    } else {
                                        Toast.makeText(contextItem, string.delete_error, Toast.LENGTH_SHORT).show();
                                    }
                                }).setNegativeButton("No", null).show();

                        return true;
                    default:
                        return false;
                }
            });
            popup.show();
        });
    }

    @Override
    public int getItemCount() {
        return classInventory.size();
    }


    static class ItemHolder extends RecyclerView.ViewHolder {

        private inventoryClass itemViewChild;
        private final TextView nameViewChild;
        private final EditText quantityViewChild;

        // Instance of the databaseHelper
        com.example.project3nicolepenner.databaseHelper databaseHelper;
        ImageButton increaseButton;
        ImageButton decreaseButton;
        ImageButton actionsButtons;

        public ItemHolder(View itemView, com.example.project3nicolepenner.databaseHelper inventoryDb) {
            super(itemView);
            databaseHelper = inventoryDb;

            nameViewChild = itemView.findViewById(id.itemName);
            quantityViewChild = itemView.findViewById(id.editQuantity);

            increaseButton = itemView.findViewById(id.increaseButton);
            decreaseButton = itemView.findViewById(id.decreaseButton);
            actionsButtons = itemView.findViewById(id.actionsButtons);

            // Increment by 1 when button is clicked
            increaseButton.setOnClickListener(v -> {
                itemViewChild.incrementQuantity();
                boolean updated = databaseHelper.itemUpdate(itemViewChild);
                if (updated) {
                    quantityViewChild.setText(String.valueOf(itemViewChild.getQuantity()));
                }
            });

            // Decrement -1 using decrement button
            decreaseButton.setOnClickListener(v -> {
                itemViewChild.decrementQuantity();
                boolean updated = databaseHelper.itemUpdate(itemViewChild);
                if (updated) {
                    quantityViewChild.setText(String.valueOf(itemViewChild.getQuantity()));
                }
            });



            // Apply changes to databaseHelper when updates are saved
            quantityViewChild.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                    itemViewChild.setQuantity(convertItem());
                    boolean updated = databaseHelper.itemUpdate(itemViewChild);
                    Log.d(TAG, "Update successful: " + updated);

                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });
        }

        // Bind item
        public void bindItem(inventoryClass item) {
            itemViewChild = item;
            Log.d("ItemHolder", "Bind item: " + itemViewChild.getName());
            nameViewChild.setText(itemViewChild.getName());
            quantityViewChild.setText(String.valueOf(itemViewChild.getQuantity()));
        }

        // Item input to number value
        private int convertItem() {
            String rawValue = quantityViewChild.getText().toString().replaceAll("[^\\d.]", "").trim();
            int quantity = rawValue.isEmpty() ? 0 : Integer.parseInt(rawValue);

            // 0 is the max/min
            return Math.max(quantity, 0);
        }
    }
}
