package com.example.project3nicolepenner;

import java.io.Serializable;

public class inventoryClass implements Serializable {
    private long iDInventory;
    private String nameInventory;
    private int quantityInventory;

    public inventoryClass() {
    }

    public inventoryClass(long id, String name) {
        iDInventory = id;
        nameInventory = name;
        quantityInventory = 0;
    }

    public inventoryClass(long id, String name, int quantity) {
        iDInventory = id;
        nameInventory = name;
        quantityInventory = quantity;
    }

    // Gets & sets ID
    public long getId() {
        return iDInventory;
    }
    public void setId(long id) {
        this.iDInventory = id;
    }

    // Gets & sets name
    public String getName() {
        return nameInventory;
    }
    public void setName(String name) {
        this.nameInventory = name;
    }

    //Gets & Sets Quantity
    public int getQuantity() {
        return quantityInventory;
    }
    public void setQuantity(int quantity) {
        this.quantityInventory = Math.max(0, quantity);
    }

    // Only increase/decrease quantity by 1
    public void incrementQuantity() {
        this.quantityInventory++;
    }
    public void decrementQuantity() {
        this.quantityInventory = Math.max(0, this.quantityInventory - 1);
    }
}
