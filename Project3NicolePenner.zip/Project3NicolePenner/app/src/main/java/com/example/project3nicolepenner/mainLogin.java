package com.example.project3nicolepenner;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.security.MessageDigest;

public class mainLogin extends AppCompatActivity {

    //Login databaseHelper
    com.example.project3nicolepenner.databaseHelper databaseHelper;

    EditText userInput;
    EditText passInput;
    Button loginButton;
    Button registerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.app_login);

        // get databaseHelper
        databaseHelper = databaseHelper.getInstance(this);

        userInput = findViewById(R.id.usernameInput);
        passInput = findViewById(R.id.passwordInput);
        userInput.addTextChangedListener(inputChanges);
        passInput.addTextChangedListener(inputChanges);

        loginButton = findViewById(R.id.loginButton);
        registerButton = findViewById(R.id.registerButton);

        //buttons not enabled when app starts up
        loginButton.setEnabled(false);
        registerButton.setEnabled(false);

    }

    // Login and register buttons become available after input is added to both
    private final TextWatcher inputChanges;

    {
        inputChanges = new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                boolean fieldsAreEmpty = getUsername().isEmpty() || getPassword().isEmpty();
                loginButton.setEnabled(!fieldsAreEmpty);
                registerButton.setEnabled(!fieldsAreEmpty);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        };
    }

    // Error message
    public void login(View view) {
        if (validCredentials()) {
            showError(view.getContext().getResources().getString(R.string.invalid_login));
            return;
        }

        try {
            boolean isLoggedIn = databaseHelper.checkUser(getUsername(), hash(getPassword()));

            if (isLoggedIn) {
                handleLoggedInUser();
            } else {
                showError(view.getContext().getResources().getString(R.string.invalid_login));
            }
        } catch (Exception e) {
            showError(view.getContext().getResources().getString(R.string.invalid_login));
        }
    }

    // Register new user
    public void register(View view) {
        if (validCredentials()) {
            showError(view.getContext().getResources().getString(R.string.existing_login));
        }

        try {
            boolean userCreated = databaseHelper.addUser(getUsername(), hash(getPassword()));

            if (userCreated) {
                handleLoggedInUser();
            } else {
                showError(view.getContext().getResources().getString(R.string.existing_login));
            }
        } catch (Exception e) {
            showError(view.getContext().getResources().getString(R.string.existing_login));
        }
    }

    // If user exists, log-in
    private void handleLoggedInUser() {
        Intent intent = new Intent(getApplicationContext(), listInventory.class);
        startActivity(intent);
    }
    private boolean validCredentials() {
        return getUsername().isEmpty() || getPassword().isEmpty();
    }

    // Get/Return Username
    private String getUsername() {
        Editable username = userInput.getText();
        return username != null ? username.toString().trim().toLowerCase() : "";
    }

    // Get/Return Password
    private String getPassword() {
        Editable password = passInput.getText();
        return password != null ? password.toString().trim() : "";
    }

    // Password encryption function
    private String hash(String password) throws Exception {
        MessageDigest passEncrypt = MessageDigest.getInstance("MD5");
        passEncrypt.update(password.getBytes());
        byte[] digest = passEncrypt.digest();
        StringBuilder sb = new StringBuilder();
        for (byte b : digest) {
            sb.append(String.format("%02x", b & 0xff));
        }

        return sb.toString();
    }

    private void showError(String errorMessage) {
        Toast toast = Toast.makeText(getApplicationContext(), errorMessage, Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER, 0, -200);
        toast.show();
    }
}
