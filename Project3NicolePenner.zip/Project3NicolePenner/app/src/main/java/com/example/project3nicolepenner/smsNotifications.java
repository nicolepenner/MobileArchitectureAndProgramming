package com.example.project3nicolepenner;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.CompoundButton;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.switchmaterial.SwitchMaterial;

public class smsNotifications extends AppCompatActivity {

    private static final String TAG = "smsNotifications";
    public static String RECEIVE_SMS_NOTIFICATIONS = "RECEIVE_SMS_NOTIFICATIONS";
    private final int CLICK_TO_RECEIVE_SMS = 0;
    boolean smsNotifications = false;

    SwitchMaterial toggleSMS;
    SharedPreferences sharePreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        setContentView(R.layout.sms_notification_toggle);

        toggleSMS = findViewById(R.id.notificationsToggle);

        toggleSMS.setOnCheckedChangeListener(this::onCheckedChanged);

        sharePreferences = PreferenceManager.getDefaultSharedPreferences(this);
        smsNotifications = sharePreferences.getBoolean(RECEIVE_SMS_NOTIFICATIONS, false);

        if (smsNotifications
                && ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED
        ) {
            toggleSMS.setChecked(true);
        }
    }

    // Asks permission
    // If no then yes, if yes then no
    // Saves previous selection
    private boolean hasPermissions() {
        String smsPermission = Manifest.permission.SEND_SMS;

        if (ContextCompat.checkSelfPermission(this, smsPermission)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this, smsPermission)) {
                new AlertDialog.Builder(this)
                        .setTitle(R.string.smsPermission)
                        .setMessage(R.string.smsToggleAction)
                        .setPositiveButton("OK", (dialog, which) -> {
                            // Actually request permission from the user
                            ActivityCompat.requestPermissions(
                                    smsNotifications.this,
                                    new String[]{smsPermission},
                                    CLICK_TO_RECEIVE_SMS
                            );
                        })
                        .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                        .create()
                        .show();
            } else {
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{smsPermission},
                        CLICK_TO_RECEIVE_SMS
                );
            }
            return false;
        }
        return true;
    }

    //toggle function
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CLICK_TO_RECEIVE_SMS) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d(TAG, "Permission granted");
                smsNotifications = true;
                toggleSMS.setChecked(true);
            } else {
                Log.d(TAG, "Permission denied");
                smsNotifications = false;
                toggleSMS.setChecked(false);
            }

            savePreferences();
        }
    }

    private void savePreferences() {
        SharedPreferences.Editor editor = sharePreferences.edit();
        editor.putBoolean(RECEIVE_SMS_NOTIFICATIONS, smsNotifications);
        editor.apply();
    }

    private void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        smsNotifications = isChecked;
        // Check for permissions
        if (isChecked && hasPermissions()) {
            Log.d(TAG, "Wants notifications");
            toggleSMS.setChecked(true);
        } else {
            Log.d(TAG, "Does not want notifications");
            toggleSMS.setChecked(false);
            smsNotifications = false;
        }
        savePreferences();
    }
}
